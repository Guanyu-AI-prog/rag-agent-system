"""
LangChain RAG API服务
基于FastAPI，支持RESTful接口
"""

import os
import time
import asyncio
import hashlib
import uuid
import logging
from logging.handlers import RotatingFileHandler
from collections import deque
from typing import Dict, Any, Optional, List
from concurrent.futures import ThreadPoolExecutor
from threading import Lock

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import uvicorn

from workflow_langchain import RAGWorkflow
from conversation_history import ConversationManager
from config import Config


def setup_logging():
    os.makedirs(Config.LOG_DIR, exist_ok=True)
    logger = logging.getLogger()
    logger.setLevel(getattr(logging, Config.LOG_LEVEL.upper()))
    logger.handlers.clear()

    formatter = logging.Formatter(Config.LOG_FORMAT)

    file_handler = RotatingFileHandler(
        Config.LOG_FILE,
        maxBytes=Config.LOG_MAX_SIZE * 1024 * 1024,
        backupCount=Config.LOG_BACKUP_COUNT,
        encoding='utf-8'
    )
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    return logger


logger = setup_logging()


class QueryRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=1000, description="用户问题")
    session_id: Optional[str] = Field(None, description="会话ID（可选）")
    user_id: Optional[str] = Field(None, description="用户ID（可选）")


class QueryResponse(BaseModel):
    answer: str = Field(..., description="回答内容")
    sources: List[str] = Field(default_factory=list, description="来源文档")
    success: bool = Field(True, description="是否成功")
    processing_time: Optional[float] = Field(None, description="处理时间（秒）")
    token_usage: Optional[Dict[str, Any]] = Field(None, description="Token使用情况")
    session_id: Optional[str] = Field(None, description="会话ID")


class HealthResponse(BaseModel):
    status: str = Field(..., description="服务状态")
    service: str = Field(..., description="服务名称")
    version: str = Field(..., description="版本号")
    timestamp: float = Field(..., description="时间戳")


class StatsResponse(BaseModel):
    status: str = Field(..., description="状态")
    document_count: Optional[int] = Field(None, description="文档数量")
    llm_model: Optional[str] = Field(None, description="LLM模型")
    embedding_model: Optional[str] = Field(None, description="嵌入模型")


class EnhancedSimpleCache:
    """增强版内存缓存：支持统计和LRU淘汰"""

    def __init__(self, ttl_seconds: int = 300, max_size: int = 1000, enable_stats: bool = True):
        self.cache: Dict[str, Dict[str, Any]] = {}
        self.lock = Lock()
        self.ttl = ttl_seconds
        self.max_size = max_size
        self.enable_stats = enable_stats
        self.hits = 0
        self.misses = 0
        self.evictions = 0
        self.lru_queue = deque()

    def get(self, key: str) -> Optional[Any]:
        with self.lock:
            if key in self.cache:
                entry = self.cache[key]
                if time.time() - entry['timestamp'] < self.ttl:
                    if key in self.lru_queue:
                        self.lru_queue.remove(key)
                    self.lru_queue.append(key)
                    if self.enable_stats:
                        self.hits += 1
                    return entry['value']
                else:
                    del self.cache[key]
                    if key in self.lru_queue:
                        self.lru_queue.remove(key)
            if self.enable_stats:
                self.misses += 1
            return None

    def set(self, key: str, value: Any):
        with self.lock:
            if key in self.lru_queue:
                self.lru_queue.remove(key)

            if len(self.cache) >= self.max_size and key not in self.cache:
                if self.lru_queue:
                    lru_key = self.lru_queue.popleft()
                    if lru_key in self.cache:
                        del self.cache[lru_key]
                        if self.enable_stats:
                            self.evictions += 1

            self.cache[key] = {
                'value': value,
                'timestamp': time.time()
            }
            self.lru_queue.append(key)

    def clear(self):
        with self.lock:
            self.cache.clear()
            self.lru_queue.clear()
            if self.enable_stats:
                self.hits = 0
                self.misses = 0
                self.evictions = 0

    def size(self) -> int:
        with self.lock:
            return len(self.cache)

    def get_stats(self) -> Dict[str, Any]:
        with self.lock:
            total = self.hits + self.misses
            hit_rate = (self.hits / total * 100) if total > 0 else 0
            return {
                "size": len(self.cache),
                "max_size": self.max_size,
                "hits": self.hits,
                "misses": self.misses,
                "hit_rate": f"{hit_rate:.1f}%",
                "evictions": self.evictions,
                "ttl_seconds": self.ttl
            }


async def monitor_cache_stats():
    logger.info(f"缓存监控已启动，记录间隔: {Config.CACHE_MONITOR_INTERVAL}秒")
    while True:
        try:
            await asyncio.sleep(Config.CACHE_MONITOR_INTERVAL)
            if cache:
                stats = cache.get_stats()
                logger.info(
                    f"缓存监控 - "
                    f"命中率: {stats['hit_rate']} | "
                    f"大小: {stats['size']}/{stats['max_size']} | "
                    f"命中: {stats['hits']} | "
                    f"未命中: {stats['misses']} | "
                    f"淘汰: {stats['evictions']}"
                )
        except asyncio.CancelledError:
            logger.info("缓存监控任务已取消")
            break
        except Exception as e:
            logger.error(f"缓存监控错误: {e}")


def _postprocess_answer(answer: str, question: str = "") -> str:
    if "抱歉，暂未找到相关信息" not in answer:
        return answer
    if any(kw in question for kw in ["wifi", "WiFi", "无线"]):
        return "您是否想了解宽带融合套餐？例如99元套餐含100M宽带，129元套餐含300M宽带。"
    if any(kw in question for kw in ["兆", " M", "速率"]):
        return "各档位宽带速率参考：99元含100M，129元含300M，299元可选1000M宽带。您想了解哪个套餐？"
    if any(kw in question for kw in ["流量", "不够", "叠加", "通话"]):
        return "您是否想了解5G畅享29-199元系列套餐？不同档位包含不同流量和通话时长。"
    return "目前暂无该套餐的详细信息，建议您咨询人工客服或查看其他套餐。您是否想了解5G畅享29-199元系列套餐？"


def _make_cache_key(question: str, conversation_history: str = "") -> str:
    raw = f"{question}:{conversation_history}"
    return hashlib.md5(raw.encode()).hexdigest()


app = FastAPI(
    title="LangChain RAG API",
    description="基于LangChain的RAG问答系统API",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=Config.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

try:
    from fastapi.staticfiles import StaticFiles
    from fastapi.responses import RedirectResponse

    static_dir = "static"
    if os.path.exists(static_dir):
        app.mount("/static", StaticFiles(directory=static_dir), name="static")
        logger.info(f"静态文件目录已挂载: {static_dir}")
    else:
        logger.warning(f"静态文件目录不存在: {static_dir}")
except ImportError:
    logger.warning("无法导入StaticFiles，静态文件服务不可用")
except Exception as e:
    logger.error(f"静态文件挂载失败: {e}")

workflow = None
cache = None
executor = None
monitor_task = None
conversation_manager = None


@app.on_event("startup")
async def startup_event():
    global workflow, cache, executor, conversation_manager, monitor_task

    logger.info("启动RAG API服务...")

    workflow = RAGWorkflow()

    cache = EnhancedSimpleCache(
        ttl_seconds=Config.CACHE_TTL,
        max_size=Config.CACHE_MAX_SIZE,
        enable_stats=Config.CACHE_STATISTICS
    )

    conversation_manager = ConversationManager(
        max_history=Config.CONVERSATION_MAX_HISTORY,
        ttl_seconds=Config.CONVERSATION_TTL,
        max_sessions=Config.CONVERSATION_MAX_SESSIONS
    )
    logger.info(f"会话管理器已初始化 | 最大历史: {Config.CONVERSATION_MAX_HISTORY}轮 | TTL: {Config.CONVERSATION_TTL}秒")

    executor = ThreadPoolExecutor(max_workers=Config.MAX_WORKERS)

    monitor_task = asyncio.create_task(monitor_cache_stats())
    logger.info("缓存监控任务已创建")

    logger.info(f"服务初始化完成，缓存TTL: {Config.CACHE_TTL}秒，最大工作线程: {Config.MAX_WORKERS}")


@app.on_event("shutdown")
async def shutdown_event():
    global executor, monitor_task

    logger.info("关闭RAG API服务...")

    if monitor_task:
        monitor_task.cancel()
        try:
            await monitor_task
        except asyncio.CancelledError:
            pass
        logger.info("缓存监控任务已停止")

    if executor:
        executor.shutdown(wait=True)

    logger.info("清理完成")


@app.get("/", response_class=JSONResponse)
async def root():
    return {
        "message": "LangChain RAG API Service",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health",
        "web_ui": "/web"
    }


@app.get("/web", include_in_schema=False)
async def web_ui():
    try:
        return RedirectResponse(url="/static/web_ui.html")
    except Exception as e:
        return {"error": "Web UI不可用", "detail": str(e)}


@app.get("/health", response_model=HealthResponse)
async def health_check():
    return HealthResponse(
        status="healthy",
        service="rag-api",
        version="1.0.0",
        timestamp=time.time()
    )


@app.get("/stats", response_model=StatsResponse)
async def get_stats():
    if not workflow:
        raise HTTPException(status_code=503, detail="服务未就绪")
    stats = workflow.get_stats()
    return StatsResponse(**stats)


@app.post("/query", response_model=QueryResponse)
async def query_rag(request: QueryRequest):
    request_id = str(uuid.uuid4())[:8]
    start_time = time.time()
    session_id = request.session_id or str(uuid.uuid4())

    logger.info(f"[{request_id}] 收到查询请求: {request.question[:50]}... | 用户: {request.user_id or '匿名'} | 会话: {session_id}")

    if not workflow:
        logger.error(f"[{request_id}] RAG服务未就绪")
        raise HTTPException(status_code=503, detail="RAG服务未就绪")

    conversation_history_text = ""
    if conversation_manager:
        conversation_history_text = conversation_manager.format_history_for_prompt(session_id)
        if conversation_history_text:
            logger.info(f"[{request_id}] 会话历史: {len(conversation_manager.get_history(session_id)) // 2} 轮")

    cache_key = _make_cache_key(request.question, conversation_history_text)
    cached_result = cache.get(cache_key)

    if cached_result:
        processing_time = time.time() - start_time
        logger.info(f"[{request_id}] 缓存命中 | 耗时: {processing_time:.3f}s")

        if conversation_manager:
            conversation_manager.add_exchange(session_id, request.question, cached_result["answer"])

        return QueryResponse(
            answer=cached_result["answer"],
            sources=cached_result.get("sources", []),
            success=True,
            processing_time=processing_time,
            token_usage={"cached": True},
            session_id=session_id
        )

    logger.debug(f"[{request_id}] 开始执行查询（含会话历史）")
    loop = asyncio.get_event_loop()
    try:
        result = await loop.run_in_executor(
            executor,
            lambda: workflow.query(request.question, conversation_history_text)
        )

        processing_time = time.time() - start_time
        answer = _postprocess_answer(result["answer"], request.question)

        MAX_SOURCE_LEN = 200
        trimmed_sources = []
        for src in result.get("sources", []):
            clean = src.replace("\n", " ").replace("\r", " ").strip()
            if len(clean) > MAX_SOURCE_LEN:
                trimmed_sources.append(clean[:MAX_SOURCE_LEN] + "...")
            else:
                trimmed_sources.append(clean)

        if result["success"]:
            logger.info(f"[{request_id}] 查询成功 | 耗时: {processing_time:.3f}s")
            cache.set(cache_key, {"answer": answer, "sources": trimmed_sources})
        else:
            logger.warning(f"[{request_id}] 查询失败 | 耗时: {processing_time:.3f}s | 错误: {result.get('error', '未知错误')}")

        if conversation_manager and result["success"]:
            conversation_manager.add_exchange(session_id, request.question, answer)
            logger.debug(f"[{request_id}] 会话历史已更新 | 会话: {session_id}")

        return QueryResponse(
            answer=answer,
            sources=trimmed_sources,
            success=result["success"],
            processing_time=processing_time,
            token_usage=result.get("token_usage"),
            session_id=session_id
        )

    except Exception as e:
        processing_time = time.time() - start_time
        logger.error(f"[{request_id}] 查询异常 | 耗时: {processing_time:.3f}s | 异常: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"查询失败: {str(e)}")


@app.post("/batch_query")
async def batch_query(questions: List[str]):
    request_id = str(uuid.uuid4())[:8]
    logger.info(f"[{request_id}] 收到批量查询请求 | 问题数: {len(questions)}")

    if not workflow:
        raise HTTPException(status_code=503, detail="RAG服务未就绪")

    if len(questions) > Config.MAX_BATCH_SIZE:
        logger.warning(f"[{request_id}] 批量查询数量超限: {len(questions)}")
        raise HTTPException(status_code=400, detail=f"批量查询最多支持{Config.MAX_BATCH_SIZE}个问题")

    results = []
    start_time = time.time()

    for i, question in enumerate(questions):
        logger.debug(f"[{request_id}] 处理 {i+1}/{len(questions)}: {question[:30]}...")
        result = workflow.query(question)
        results.append({
            "question": question,
            "answer": result["answer"],
            "success": result["success"]
        })

    total_time = time.time() - start_time
    logger.info(f"[{request_id}] 批量查询完成 | 总耗时: {total_time:.3f}s | 平均: {total_time / len(questions):.3f}s")

    return {"results": results}


@app.post("/cache/clear")
async def clear_cache():
    request_id = str(uuid.uuid4())[:8]
    logger.info(f"[{request_id}] 清空缓存")

    if cache:
        cache.clear()
        logger.info(f"[{request_id}] 缓存已清空")
        return {"message": "缓存已清空", "status": "success"}

    return {"message": "缓存未初始化", "status": "error"}


@app.get("/cache/stats")
async def cache_stats():
    if cache:
        stats = cache.get_stats()
        stats["status"] = "active"
        return stats
    return {"status": "inactive"}


@app.post("/conversation/clear")
async def clear_conversation(session_id: str = Query(..., description="要清除历史的会话ID")):
    request_id = str(uuid.uuid4())[:8]
    logger.info(f"[{request_id}] 清除会话历史: {session_id}")

    if conversation_manager:
        success = conversation_manager.clear_history(session_id)
        if success:
            return {"message": "会话历史已清除", "session_id": session_id, "status": "success"}
        else:
            return {"message": "会话不存在", "session_id": session_id, "status": "not_found"}

    return {"message": "会话管理器未初始化", "status": "error"}


@app.get("/conversation/stats")
async def conversation_stats():
    if conversation_manager:
        stats = conversation_manager.get_stats()
        stats["status"] = "active"
        return stats
    return {"status": "inactive"}


@app.post("/reload")
async def reload_workflow():
    global workflow
    request_id = str(uuid.uuid4())[:8]

    logger.info(f"[{request_id}] 重新加载工作流")

    try:
        workflow = RAGWorkflow()
        return {"message": "工作流重新加载成功", "status": "success"}
    except Exception as e:
        logger.error(f"[{request_id}] 工作流重新加载失败: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"重新加载失败: {str(e)}")


@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    request_id = str(uuid.uuid4())[:8]
    logger.error(f"[{request_id}] 未处理异常: {str(exc)}", exc_info=True)

    return JSONResponse(
        status_code=500,
        content={
            "error": "内部服务器错误",
            "detail": str(exc),
            "type": type(exc).__name__,
            "request_id": request_id
        }
    )


def main():
    print("=" * 50)
    print("LangChain RAG API Service")
    print("=" * 50)

    Config.print_config()

    print(f"\n启动服务: http://{Config.API_HOST}:{Config.API_PORT}")
    print(f"API文档: http://{Config.API_HOST}:{Config.API_PORT}/docs")
    print(f"健康检查: http://{Config.API_HOST}:{Config.API_PORT}/health")
    print(f"日志文件: {Config.LOG_FILE}")
    print(f"Web UI: http://{Config.API_HOST}:{Config.API_PORT}/web")
    print("=" * 50)

    logger.info("API服务启动")

    uvicorn.run(
        "api:app",
        host=Config.API_HOST,
        port=Config.API_PORT,
        reload=False,
        workers=1,
        log_level="info",
        access_log=True
    )


if __name__ == "__main__":
    main()
