"""
LangChain RAG工作流核心实现
支持文档加载、分割、向量化、检索和生成
"""

import os
import sys
import hashlib
from typing import List, Dict, Any, Optional
from pathlib import Path
import logging
import re
from concurrent.futures import ThreadPoolExecutor, as_completed

from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import TextLoader, DirectoryLoader
from langchain_chroma import Chroma
from langchain_openai import ChatOpenAI
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import PromptTemplate
from langchain_core.documents import Document

from config import Config
import requests

logger = logging.getLogger(__name__)


class RAGWorkflow:
    """RAG工作流类"""

    def __init__(self):
        logger.info("初始化RAG工作流...")
        Config.validate()

        self.embedding = None
        self.vectorstore = None
        self.llm = None
        self.qa_chain = None
        self.retriever = None
        self._executor = ThreadPoolExecutor(max_workers=4)

        self._init_embedding()
        self._init_llm()
        self._init_vectorstore()
        self._init_qa_chain()

        logger.info("RAG工作流初始化完成")

    def _init_embedding(self):
        logger.info("初始化本地嵌入模型...")
        try:
            from local_embeddings import LocalBGEEmbeddings
            self.embedding = LocalBGEEmbeddings(model_name=Config.EMBED_MODEL)
            logger.info("本地嵌入模型加载成功")
        except ImportError as e:
            raise ImportError(f"本地嵌入模型不可用: {e}。请安装sentence-transformers库。")
        except Exception as e:
            raise RuntimeError(f"本地嵌入模型加载失败: {e}")

    def _init_llm(self):
        logger.info(f"初始化LLM模型: {Config.LLM_MODEL}")
        api_key = Config.LLM_API_KEY or Config.SILICONFLOW_API_KEY
        api_base = Config.LLM_API_BASE or Config.SILICONFLOW_API_BASE
        logger.info(f"LLM API: {api_base}")

        self.llm = ChatOpenAI(
            openai_api_key=api_key,
            openai_api_base=api_base,
            model_name=Config.LLM_MODEL,
            temperature=Config.LLM_TEMPERATURE,
            max_tokens=Config.LLM_MAX_TOKENS
        )

    def _init_vectorstore(self):
        abs_path = os.path.abspath(Config.VECTOR_DB_PATH)
        logger.info(f"初始化向量数据库: {abs_path}")

        if not os.path.exists(abs_path):
            logger.info("向量库不存在，请先运行 build_vectors.py 构建")
            self.vectorstore = None
            return

        try:
            self.vectorstore = Chroma(
                persist_directory=abs_path,
                embedding_function=self.embedding,
                collection_name=Config.COLLECTION_NAME
            )
            count = self.vectorstore._collection.count()
            logger.info(f"向量库加载成功，文档块数量: {count}")
        except Exception as e:
            logger.error(f"向量库加载失败: {e}")
            self.vectorstore = None

    def _init_qa_chain(self):
        if not self.vectorstore:
            logger.warning("向量库未初始化，跳过QA链初始化")
            return

        logger.info("初始化检索问答链...")
        self.retriever = self.vectorstore.as_retriever(
            search_type="similarity",
            search_kwargs={"k": Config.RETRIEVAL_K}
        )

        template = """你是一个专业的电信客服助手。请严格基于提供的上下文信息回答。

【重要规则】
1. 只能基于提供的上下文信息回答，不要编造信息
2. 如果上下文中有相关信息，请直接回答
3. 如果上下文中没有精确匹配，但有相关套餐信息，可以推荐相关套餐作为参考
4. 如果用户提到"wifi"或"无线"，应主动询问是否需要了解宽带服务
5. 如果用户问"多少兆"或"几M"，应主动询问是否需要了解宽带速率
6. 如果用户问"多少钱"或"资费"，应主动给出月费信息
7. 回答要简洁（100-200字），友好且专业，使用中文回答
8. 如果上下文信息为空或不相关，根据用户问题关键词推测意图并引导：
   - 提到wifi/无线 → "目前暂无该套餐的宽带信息，您是否想了解我们的宽带融合套餐？例如99元套餐含100M宽带。"
   - 提到兆/M/速率 → "您是否想了解各档位套餐的宽带速率？99元含100M，129元含300M，299元可选1000M。"
   - 提到流量/通话 → "您是否想了解5G畅享29-199元系列套餐？各档位流量和通话时长不同。"
9. 【关键】上下文中可能包含多个套餐档位的数据表格。你必须只提取与用户问题中指定的套餐档位（如99元/59元/129元等）完全匹配的行数据，绝不能把其他档位的数据套用到用户询问的套餐上。

【示例1】
用户问题："畅享99套餐包含多少流量"
上下文信息："畅享99套餐包含20GB国内通用流量"
正确回答："畅享99元套餐包含20GB国内通用流量。"

【示例2】
用户问题："这个套餐wifi多少兆"
上下文信息："（空）"
正确回答："您是否想了解我们的宽带融合套餐？99元套餐含100M宽带，129元套餐含300M宽带。"

【上下文信息】
{context}

【用户问题】
{question}

【回答】"""

        prompt = PromptTemplate(template=template, input_variables=["context", "question"])

        def format_docs(docs):
            return "\n\n".join(doc.page_content for doc in docs)

        self.qa_chain = (
            {"context": self.retriever | format_docs, "question": RunnablePassthrough()}
            | prompt
            | self.llm
            | StrOutputParser()
        )
        logger.info("QA链初始化完成")

    def load_documents(self, data_dir: str = None) -> int:
        if data_dir is None:
            data_dir = Config.DATA_DIR

        logger.info(f"从 {data_dir} 加载文档...")
        if not os.path.exists(data_dir):
            logger.warning(f"数据目录不存在: {data_dir}")
            return 0

        documents = []
        for pattern in ["**/*.txt", "**/*.md"]:
            loader = DirectoryLoader(
                data_dir,
                glob=pattern,
                loader_cls=TextLoader,
                loader_kwargs={"encoding": "utf-8"}
            )
            try:
                documents.extend(loader.load())
            except Exception as e:
                logger.warning(f"加载 {pattern} 文件失败: {e}")

        if not documents:
            logger.warning("未找到文档文件")
            return 0

        logger.info(f"找到 {len(documents)} 个文档")

        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=Config.CHUNK_SIZE,
            chunk_overlap=Config.CHUNK_OVERLAP,
            separators=Config.CHUNK_SEPARATORS
        )
        texts = text_splitter.split_documents(documents)
        logger.info(f"分割为 {len(texts)} 个文本块")

        if self.vectorstore is None:
            logger.info("创建新向量库...")
            self.vectorstore = Chroma.from_documents(
                documents=texts,
                embedding=self.embedding,
                persist_directory=Config.VECTOR_DB_PATH,
                collection_name=Config.COLLECTION_NAME
            )
        else:
            logger.info("添加到现有向量库...")
            self.vectorstore.add_documents(texts)

        logger.info(f"向量库已保存到: {Config.VECTOR_DB_PATH}")
        self._init_qa_chain()
        return len(texts)

    def _is_comparison_question(self, question: str) -> bool:
        comparison_patterns = [
            r'和.*对比', r'与.*对比', r'对比', r'相比',
            r'哪个更', r'哪个.*多', r'哪个.*少',
            r'多少.*对比', r'区别', r'差异', r'比较', r'高低', r'大小'
        ]
        return any(re.search(p, question) for p in comparison_patterns)

    def _extract_comparison_entities(self, question: str) -> List[str]:
        package_patterns = [
            r'(?:5G)?畅享\d+元?(?:套餐)?',
            r'星卡\d+(?:套餐)?',
            r'\d+G畅享\d+(?:套餐)?',
        ]

        entities = []
        for pattern in package_patterns:
            for match in re.findall(pattern, question):
                clean = match.strip()
                if clean and clean not in entities:
                    entities.append(clean)

        if not entities:
            for num in re.findall(r'(\d+)\s*(?:元|套餐)', question):
                entity = f"{num}元"
                if entity not in entities:
                    entities.append(entity)

        cleaned = []
        for e in entities:
            is_subsumed = any(other != e and e in other and len(other) > len(e) for other in entities)
            if not is_subsumed:
                cleaned.append(e)
        return cleaned

    def _handle_comparison_question(self, question: str, entities: List[str], conversation_history: str = "") -> Dict[str, Any]:
        logger.info(f"检测到对比问题，实体: {entities}")

        def normalize_entity(e: str) -> str:
            return re.sub(r'^5G', '', e).replace('元', '').replace('套餐', '').strip()

        def entity_matches_doc(entity: str, content: str) -> bool:
            name = normalize_entity(entity)
            if name in content:
                return True
            for num in re.findall(r'\d+', entity):
                if re.search(rf'(?<!\d){re.escape(num)}(?!\d)元', content):
                    return True
                if re.search(rf'(?<!\d){re.escape(num)}(?!\d)套餐', content):
                    return True
            return False

        def build_search_queries(entity):
            return [
                f"{entity} 月基本费 流量 GB",
                f"{entity} 语音 分钟 通话",
                f"{entity} 宽带 安装 融合",
            ]

        def search_entity(entity):
            all_docs = []
            seen = set()
            for q in build_search_queries(entity):
                docs = self.vectorstore.similarity_search(q, k=Config.COMPARISON_RETRIEVAL_K)
                for d in docs:
                    if d.page_content not in seen and entity_matches_doc(entity, d.page_content):
                        seen.add(d.page_content)
                        all_docs.append(d)
            return entity, all_docs

        def extract_key_fields(content: str) -> str:
            lines = content.split("\n")
            key_lines = [
                line.strip() for line in lines
                if any(kw in line.strip() for kw in Config.COMPARISON_KEYWORDS)
            ]
            return "\n".join(key_lines) if key_lines else content[:300]

        entity_docs = {}
        all_sources = []

        with self._executor as ex:
            futures = {ex.submit(search_entity, e): e for e in entities}
            for future in as_completed(futures):
                entity, docs = future.result()
                if docs:
                    entity_docs[entity] = docs
                    all_sources.extend([extract_key_fields(doc.page_content) for doc in docs])

        seen_sources = set()
        deduped_sources = []
        for src in all_sources:
            if src not in seen_sources:
                seen_sources.add(src)
                deduped_sources.append(src)
        all_sources = deduped_sources[:50]

        context_parts = []
        for entity, docs in entity_docs.items():
            entity_context = f"=== {entity} ===\n"
            key_content = "\n---\n".join([extract_key_fields(doc.page_content) for doc in docs[:15]])
            entity_context += key_content
            context_parts.append(entity_context)

        comparison_context = "\n\n".join(context_parts)
        history_block = f"\n【对话历史】\n{conversation_history}\n" if conversation_history else ""

        prompt = f"""你是一个专业的电信客服助手。请根据以下上下文信息，对用户询问的套餐进行对比分析。
{history_block}
【对比要求】
1. 只提取并对比以下三个关键维度的信息：
   - 流量：包含多少GB国内通用流量、定向流量
   - 通话：包含多少分钟语音通话
   - 宽带：是否包含宽带，宽带速率和费用
2. 如果某个维度的信息在上下文中不存在，请标注"暂无信息"
3. 【关键】上下文中可能包含多个套餐档位的数据，你必须只提取与正在对比的套餐档位完全匹配的数据行
4. 用表格形式呈现对比结果
5. 如果信息足够，给出适合不同用户群体的建议

【上下文信息】
{comparison_context}

【用户问题】
{question}

【对比分析】"""

        try:
            answer = self.llm.invoke(prompt).content
            return {
                "answer": answer,
                "sources": all_sources[:10],
                "token_usage": {"total_tokens": 0, "total_cost": 0},
                "success": True
            }
        except Exception as e:
            logger.error(f"对比分析失败: {e}")
            return {"answer": f"查询失败：{str(e)}", "sources": [], "success": False}

    def _expand_query_intent(self, question: str) -> str:
        expanded = question
        for keyword, expansion in Config.INTENT_EXPANSIONS.items():
            if keyword in question:
                expanded += f" {expansion}"
                logger.info(f"意图识别: '{keyword}' -> 扩展关键词 '{expansion}'")
        return expanded

    def _rerank_documents(self, query: str, documents: List[Document], top_k: int = 5) -> List[Document]:
        if not documents:
            return []

        url = Config.RERANK_API_URL
        headers = {
            "Authorization": f"Bearer {Config.SILICONFLOW_API_KEY}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": Config.RERANK_MODEL,
            "query": query,
            "documents": [doc.page_content for doc in documents],
            "top_n": top_k,
            "return_documents": False
        }

        for attempt in range(Config.RERANK_MAX_RETRIES):
            try:
                response = requests.post(url, headers=headers, json=payload, timeout=Config.RERANK_TIMEOUT)
                response.raise_for_status()
                result = response.json()

                reranked_docs = []
                for item in result.get("results", []):
                    index = item["index"]
                    reranked_docs.append(documents[index])
                return reranked_docs[:top_k]
            except Exception as e:
                logger.warning(f"Rerank尝试 {attempt + 1}/{Config.RERANK_MAX_RETRIES} 失败: {e}")

        logger.warning("Rerank全部失败，返回原始文档")
        return documents[:top_k]

    def query(self, question: str, conversation_history: str = "") -> Dict[str, Any]:
        if not question or not question.strip():
            return {"answer": "请输入有效的问题", "sources": [], "success": False, "error": "empty_question"}

        if len(question) > Config.MAX_QUERY_LENGTH:
            return {"answer": f"问题长度不能超过{Config.MAX_QUERY_LENGTH}个字符", "sources": [], "success": False, "error": "query_too_long"}

        if not self.vectorstore:
            return {
                "answer": "向量库未初始化，请先运行 build_vectors.py 构建向量库",
                "sources": [], "success": False, "error": "vectorstore_not_initialized"
            }

        rewritten_question = re.sub(r'(?<!\w)(\d+)G(?!\w)', r'\1GB', question)
        rewritten_question = self._expand_query_intent(rewritten_question)
        for key, value in Config.QUERY_SYNONYMS.items():
            if key in rewritten_question and value not in rewritten_question:
                rewritten_question = f"{rewritten_question} {value}"

        price_match = re.search(r'(\d+)\s*元', question)
        if price_match:
            rewritten_question += f" {price_match.group(1)}元"

        if rewritten_question != question:
            logger.info(f"查询改写: '{question}' -> '{rewritten_question}'")
            question = rewritten_question

        logger.info(f"查询: {question[:50]}...")

        if self._is_comparison_question(question):
            entities = self._extract_comparison_entities(question)
            if len(entities) >= 2:
                logger.info(f"检测到对比问题: {entities}")
                return self._handle_comparison_question(question, entities, conversation_history)

        try:
            if Config.USE_RERANK:
                return self._query_with_rerank(question, conversation_history)
            else:
                return self._query_with_chain(question, conversation_history)
        except Exception as e:
            logger.error(f"查询失败: {str(e)}", exc_info=True)
            return {"answer": f"查询失败：{str(e)}", "sources": [], "success": False, "error": str(e)}

    def _query_with_rerank(self, question: str, conversation_history: str) -> Dict[str, Any]:
        docs = self.vectorstore.similarity_search(question, k=Config.RERANK_TOP_K)
        if not docs:
            return {"answer": self._get_fallback_answer(question), "sources": [], "success": True}

        reranked_docs = self._rerank_documents(question, docs, top_k=Config.RETRIEVAL_K)

        price_match = re.search(r'(\d+)\s*元', question)
        if price_match:
            target_price = price_match.group(1)
            filtered_docs = [d for d in reranked_docs if target_price in d.page_content]
            if filtered_docs:
                reranked_docs = filtered_docs

        context = "\n\n".join([doc.page_content for doc in reranked_docs])
        history_block = f"\n【对话历史】\n{conversation_history}\n" if conversation_history else ""

        prompt = f"""你是一个专业的电信客服助手。请严格根据以下上下文信息回答用户问题。
{history_block}
【重要规则】
1. 只能基于提供的上下文信息回答，不要编造信息
2. 【关键】上下文中可能包含多个套餐档位的数据表格。你必须只提取与用户问题中指定的套餐档位完全匹配的行数据
3. 如果上下文中没有相关信息，根据用户问题推测意图并引导
4. 回答要简洁（100-200字），直接给出关键信息
5. 使用中文回答

【上下文信息】
{context}

【用户问题】
{question}

【回答】"""

        try:
            answer = self.llm.invoke(prompt).content
            sources = [doc.page_content for doc in reranked_docs]
            return {
                "answer": answer, "sources": sources,
                "token_usage": {"total_tokens": 0, "total_cost": 0}, "success": True
            }
        except Exception as e:
            logger.error(f"查询失败: {e}")
            return {"answer": f"查询失败：{str(e)}", "sources": [], "success": False}

    def _query_with_chain(self, question: str, conversation_history: str) -> Dict[str, Any]:
        if not self.qa_chain:
            return {"answer": "QA链未初始化", "sources": [], "success": False, "error": "qa_chain_not_initialized"}

        try:
            query_input = question
            if conversation_history:
                query_input = f"【对话历史】\n{conversation_history}\n\n【当前问题】\n{question}"

            answer = self.qa_chain.invoke(query_input)
            source_docs = self.retriever.invoke(question)
            sources = [doc.page_content for doc in source_docs]

            return {
                "answer": answer, "sources": sources,
                "token_usage": {"total_tokens": 0, "total_cost": 0}, "success": True
            }
        except Exception as e:
            logger.error(f"查询失败: {e}")
            return {"answer": f"查询失败：{str(e)}", "sources": [], "success": False}

    def _get_fallback_answer(self, question: str) -> str:
        if any(kw in question for kw in ["wifi", "WiFi", "无线"]):
            return "您是否想了解宽带融合套餐？例如99元套餐含100M宽带，129元套餐含300M宽带。"
        if any(kw in question for kw in ["兆", " M", "速率"]):
            return "各档位宽带速率参考：99元含100M，129元含300M，299元可选1000M宽带。您想了解哪个套餐？"
        if any(kw in question for kw in ["流量", "不够", "叠加"]):
            return "您是否想了解5G畅享29-199元系列套餐？不同档位包含不同流量和通话时长。"
        return "抱歉，暂未找到相关信息，如需帮助请咨询人工客服"

    def batch_query(self, questions: List[str]) -> List[Dict[str, Any]]:
        if len(questions) > Config.MAX_BATCH_SIZE:
            logger.warning(f"批量查询数量超限: {len(questions)}")
            questions = questions[:Config.MAX_BATCH_SIZE]

        logger.info(f"开始批量查询 | 问题数: {len(questions)}")
        results = []
        for i, question in enumerate(questions):
            logger.debug(f"处理 {i+1}/{len(questions)}: {question[:30]}...")
            results.append(self.query(question))

        logger.info(f"批量查询完成 | 问题数: {len(questions)}")
        return results

    def get_stats(self) -> Dict[str, Any]:
        if not self.vectorstore:
            return {"status": "vectorstore_not_initialized"}
        try:
            collection = self.vectorstore._collection
            return {
                "status": "ready",
                "document_count": collection.count(),
                "vector_db_path": Config.VECTOR_DB_PATH,
                "llm_model": Config.LLM_MODEL,
                "embedding_model": Config.EMBED_MODEL,
                "chunk_size": Config.CHUNK_SIZE,
                "retrieval_k": Config.RETRIEVAL_K
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}

    def __del__(self):
        if hasattr(self, '_executor'):
            self._executor.shutdown(wait=False)


def main():
    if len(sys.argv) < 2:
        print("用法: python workflow_langchain.py <查询问题>")
        print("示例: python workflow_langchain.py '有哪些手机套餐？'")
        return

    question = sys.argv[1]
    workflow = RAGWorkflow()
    result = workflow.query(question)

    print("\n" + "=" * 50)
    print(f"问题: {question}")
    print(f"成功: {result['success']}")
    if result['success']:
        print(f"回答: {result['answer']}")
        print(f"来源文档数量: {len(result['sources'])}")
    else:
        print(f"错误: {result.get('error', '未知错误')}")
    print("=" * 50)


if __name__ == "__main__":
    main()
