"""
本地嵌入模型封装
使用 sentence-transformers 加载 BAAI/bge-small-zh-v1.5
兼容 LangChain Embeddings 接口
"""
import os
from typing import List
from langchain.embeddings.base import Embeddings


class LocalBGEEmbeddings(Embeddings):
    """本地BGE嵌入模型"""

    def __init__(self, model_name: str = "BAAI/bge-small-zh-v1.5"):
        self.model_name = model_name
        self._model = None
        self._init_model()

    def _init_model(self):
        from sentence_transformers import SentenceTransformer
        os.environ.setdefault('HF_ENDPOINT', 'https://hf-mirror.com')
        print(f"加载本地嵌入模型: {self.model_name}")
        try:
            self._model = SentenceTransformer(self.model_name, local_files_only=True)
        except OSError:
            print(f"本地未找到模型，尝试在线下载: {self.model_name}")
            self._model = SentenceTransformer(self.model_name, local_files_only=False)
        print(f"模型加载完成")

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        embeddings = self._model.encode(texts, show_progress_bar=False)
        return embeddings.tolist()

    def embed_query(self, text: str) -> List[float]:
        embedding = self._model.encode([text])
        return embedding[0].tolist()


if __name__ == "__main__":
    embedder = LocalBGEEmbeddings()

    docs = ["你好世界", "今天天气怎么样"]
    doc_embeddings = embedder.embed_documents(docs)
    print(f"文档嵌入维度: {len(doc_embeddings[0])}")

    query_embedding = embedder.embed_query("测试查询")
    print(f"查询嵌入维度: {len(query_embedding)}")

    print("本地嵌入模型测试通过")
