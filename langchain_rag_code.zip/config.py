"""
RAG系统配置管理
基于LangChain + SiliconFlow API
"""

import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    """系统配置类"""

    # ============== API配置 ==============
    SILICONFLOW_API_KEY = os.getenv("SILICONFLOW_API_KEY", "")
    SILICONFLOW_API_BASE = os.getenv("SILICONFLOW_API_BASE", "https://api.siliconflow.cn/v1")

    LLM_API_KEY = os.getenv("LLM_API_KEY", "")
    LLM_API_BASE = os.getenv("LLM_API_BASE", "https://api.xiaomimimo.com/v1")

    DINGTALK_APP_KEY = os.getenv("DINGTALK_APP_KEY", "")
    DINGTALK_APP_SECRET = os.getenv("DINGTALK_APP_SECRET", "")

    # ============== 模型配置 ==============
    LLM_MODEL = os.getenv("LLM_MODEL", "THUDM/GLM-4-9B-0414")
    LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.3"))
    LLM_MAX_TOKENS = int(os.getenv("LLM_MAX_TOKENS", "512"))

    EMBED_MODEL = os.getenv("EMBED_MODEL", "BAAI/bge-small-zh-v1.5")

    RERANK_MODEL = os.getenv("RERANK_MODEL", "BAAI/bge-reranker-v2-m3")
    USE_RERANK = os.getenv("USE_RERANK", "True").lower() == "true"
    RERANK_TOP_K = int(os.getenv("RERANK_TOP_K", "10"))
    RERANK_API_URL = os.getenv("RERANK_API_URL", "https://api.siliconflow.cn/v1/rerank")
    RERANK_TIMEOUT = int(os.getenv("RERANK_TIMEOUT", "30"))
    RERANK_MAX_RETRIES = int(os.getenv("RERANK_MAX_RETRIES", "2"))

    # ============== 向量库配置 ==============
    VECTOR_DB_PATH = os.getenv("VECTOR_DB_PATH", "./vector_db")
    COLLECTION_NAME = os.getenv("COLLECTION_NAME", "langchain_collection")

    CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "300"))
    CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "60"))
    CHUNK_SEPARATORS = ["\n\n", "\n", "###", "####", "#####", "。", "！", "？", "；", "，", " "]

    RETRIEVAL_K = int(os.getenv("RETRIEVAL_K", "3"))
    COMPARISON_RETRIEVAL_K = int(os.getenv("COMPARISON_RETRIEVAL_K", "100"))
    SIMILARITY_THRESHOLD = float(os.getenv("SIMILARITY_THRESHOLD", "0.2"))

    # ============== 查询配置 ==============
    MAX_QUERY_LENGTH = int(os.getenv("MAX_QUERY_LENGTH", "500"))
    MAX_BATCH_SIZE = int(os.getenv("MAX_BATCH_SIZE", "10"))

    INTENT_EXPANSIONS = {
        "wifi": "宽带 无线",
        "WiFi": "宽带 无线",
        "兆": "宽带 速率 M",
        "宽带": "宽带 安装 融合 兆",
        "无线": "宽带 wifi",
        "流量": "流量 基础 通用 赠送 GB 套餐",
        "流量不足": "流量 叠加包 升级",
        "不够用": "升级 叠加 套餐变更",
        "便宜": "优惠 低价 折扣 划算",
        "多少钱": "月费 月基本费 价格 资费",
        "送什么": "赠送 优惠 礼品 活动",
        "橙分期": "直降金额 月权益金 分期 合约",
        "补贴": "直降 月权益金 合约 预存",
        "直降": "橙分期 权益金",
    }

    QUERY_SYNONYMS = {
        "流量达人": "流量达人升级包",
        "合约促销": "合约促销体验包",
    }

    COMPARISON_KEYWORDS = [
        "月基本费", "月费", "流量", "语音", "通话", "分钟", "宽带",
        "国内通用流量", "国内通话", "套餐方案", "套餐内包含",
        "融合", "安装", "副卡", "共享", "合约", "承诺"
    ]

    # ============== 会话历史配置 ==============
    CONVERSATION_MAX_HISTORY = int(os.getenv("CONVERSATION_MAX_HISTORY", "5"))
    CONVERSATION_TTL = int(os.getenv("CONVERSATION_TTL", "1800"))
    CONVERSATION_MAX_SESSIONS = int(os.getenv("CONVERSATION_MAX_SESSIONS", "1000"))

    # ============== 性能配置 ==============
    MAX_WORKERS = int(os.getenv("MAX_WORKERS", "2"))

    CACHE_TTL = int(os.getenv("CACHE_TTL", "600"))
    CACHE_MAX_SIZE = int(os.getenv("CACHE_MAX_SIZE", "1000"))
    CACHE_STATISTICS = os.getenv("CACHE_STATISTICS", "True").lower() == "true"
    CACHE_MONITOR_INTERVAL = int(os.getenv("CACHE_MONITOR_INTERVAL", "300"))

    QUERY_TIMEOUT = int(os.getenv("QUERY_TIMEOUT", "120"))

    # ============== 服务配置 ==============
    API_HOST = os.getenv("API_HOST", "0.0.0.0")
    API_PORT = int(os.getenv("API_PORT", "8001"))
    DEBUG_MODE = os.getenv("DEBUG_MODE", "False").lower() == "true"

    CORS_ORIGINS = os.getenv("CORS_ORIGINS", "*").split(",")

    # ============== 路径配置 ==============
    DATA_DIR = os.getenv("DATA_DIR", "./data")

    # ============== 日志配置 ==============
    LOG_DIR = os.getenv("LOG_DIR", "./logs")
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    LOG_FILE = os.getenv("LOG_FILE", "./logs/rag.log")
    LOG_MAX_SIZE = int(os.getenv("LOG_MAX_SIZE", "10"))
    LOG_BACKUP_COUNT = int(os.getenv("LOG_BACKUP_COUNT", "5"))
    LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)-20s | %(funcName)-15s | %(message)s"

    @classmethod
    def validate(cls):
        if not cls.SILICONFLOW_API_KEY and not cls.LLM_API_KEY:
            raise ValueError("请配置 SILICONFLOW_API_KEY 或 LLM_API_KEY")

        os.makedirs(cls.VECTOR_DB_PATH, exist_ok=True)
        os.makedirs(cls.DATA_DIR, exist_ok=True)
        os.makedirs(cls.LOG_DIR, exist_ok=True)
        return True

    @classmethod
    def print_config(cls):
        print("=== RAG系统配置 ===")
        print(f"LLM模型: {cls.LLM_MODEL}")
        print(f"嵌入模型: {cls.EMBED_MODEL}")
        print(f"向量库路径: {cls.VECTOR_DB_PATH}")
        print(f"API服务: {cls.API_HOST}:{cls.API_PORT}")
        print(f"最大工作线程: {cls.MAX_WORKERS}")
        print(f"缓存时间: {cls.CACHE_TTL}秒")
        print(f"缓存最大条目: {cls.CACHE_MAX_SIZE}")
        print(f"缓存统计: {'启用' if cls.CACHE_STATISTICS else '禁用'}")
        print(f"会话历史轮次: {cls.CONVERSATION_MAX_HISTORY}轮")
        print(f"会话过期时间: {cls.CONVERSATION_TTL}秒")
        print(f"最大会话数: {cls.CONVERSATION_MAX_SESSIONS}")
        print(f"CORS Origins: {cls.CORS_ORIGINS}")
        print("=" * 30)


config = Config()

if __name__ == "__main__":
    try:
        Config.validate()
        Config.print_config()
        print("配置验证通过")
    except Exception as e:
        print(f"配置错误: {e}")
