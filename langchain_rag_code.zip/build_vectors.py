"""
向量库构建脚本
从文档构建ChromaDB向量数据库
"""

import os
import sys
import shutil
from pathlib import Path
from typing import List

from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import TextLoader
from langchain_chroma import Chroma

from config import Config


def build_vectorstore(
    data_dir: str = None,
    persist_directory: str = None,
    force_rebuild: bool = False
) -> int:
    print("=" * 50)
    print("向量库构建工具")
    print("=" * 50)

    if data_dir is None:
        data_dir = Config.DATA_DIR
    if persist_directory is None:
        persist_directory = Config.VECTOR_DB_PATH

    print(f"数据目录: {data_dir}")
    print(f"向量库路径: {persist_directory}")
    print(f"强制重建: {force_rebuild}")

    if not os.path.exists(data_dir):
        print(f"数据目录不存在: {data_dir}")
        return 0

    txt_files = list(Path(data_dir).glob("**/*.txt")) + list(Path(data_dir).glob("**/*.md"))
    if not txt_files:
        print(f"在 {data_dir} 中未找到.txt或.md文件")
        return 0

    print(f"找到 {len(txt_files)} 个文档文件:")
    for file in txt_files[:5]:
        print(f"   - {file.name}")
    if len(txt_files) > 5:
        print(f"   ... 还有 {len(txt_files) - 5} 个文件")

    if os.path.exists(persist_directory) and force_rebuild:
        print(f"清理旧向量库: {persist_directory}")
        shutil.rmtree(persist_directory)
        os.makedirs(persist_directory, exist_ok=True)

    print("初始化嵌入模型...")
    try:
        from local_embeddings import LocalBGEEmbeddings
        embedding = LocalBGEEmbeddings(model_name=Config.EMBED_MODEL)
        print("使用本地嵌入模型")
    except ImportError as e:
        raise ImportError(f"本地嵌入模型不可用: {e}。请安装sentence-transformers库。")
    except Exception as e:
        raise RuntimeError(f"本地嵌入模型加载失败: {e}")

    print("加载文档...")
    documents = []
    files = list(Path(data_dir).glob("**/*.txt")) + list(Path(data_dir).glob("**/*.md"))
    for file in files:
        try:
            loader = TextLoader(str(file), encoding="utf-8")
            docs = loader.load()
            documents.extend(docs)
        except Exception as e:
            print(f"加载 {file.name} 失败: {e}")
    print(f"加载了 {len(documents)} 个文档")

    print("分割文档 (差异化切分)...")

    def get_split_config(file_path: str):
        filename = file_path.lower()
        if any(keyword in filename for keyword in ['套餐搭配', '移动转网', '转网']):
            return (250, 50)
        elif '套餐详情' in filename:
            return (500, 100)
        else:
            return (300, 60)

    from collections import defaultdict
    grouped_docs = defaultdict(list)
    for doc in documents:
        source = doc.metadata.get('source', 'unknown')
        grouped_docs[source].append(doc)

    all_texts = []
    for source, docs in grouped_docs.items():
        chunk_size, chunk_overlap = get_split_config(source)
        print(f"  {source}: 块大小{chunk_size}, 重叠{chunk_overlap}, 文档数{len(docs)}")

        splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            separators=Config.CHUNK_SEPARATORS
        )
        texts = splitter.split_documents(docs)
        all_texts.extend(texts)

    texts = all_texts
    print(f"分割为 {len(texts)} 个文本块")

    if texts:
        print(f"分割示例（前2个块）:")
        for i, doc in enumerate(texts[:2]):
            print(f"   块{i+1}: {doc.page_content[:100]}...")

    print("创建向量数据库...")
    batch_size = 30
    vectorstore = None
    for i in range(0, len(texts), batch_size):
        batch = texts[i:i + batch_size]
        print(f"  处理批次 {i // batch_size + 1}: {len(batch)} 个文档块")
        if vectorstore is None:
            vectorstore = Chroma.from_documents(
                documents=batch,
                embedding=embedding,
                persist_directory=persist_directory,
                collection_name=Config.COLLECTION_NAME
            )
        else:
            vectorstore.add_documents(batch)

    print("向量数据库已保存")

    print("验证向量数据库...")
    collection = vectorstore._collection
    doc_count = collection.count()

    print("=" * 50)
    print(f"向量库构建完成!")
    print(f"文档块数量: {doc_count}")
    print(f"保存位置: {persist_directory}")
    print(f"嵌入模型: {Config.EMBED_MODEL}")
    print("=" * 50)

    metadata_file = os.path.join(persist_directory, "metadata.txt")
    with open(metadata_file, "w", encoding="utf-8") as f:
        f.write(f"构建时间: {__import__('datetime').datetime.now()}\n")
        f.write(f"文档数量: {len(documents)}\n")
        f.write(f"文档块数量: {doc_count}\n")
        f.write(f"块大小: {Config.CHUNK_SIZE}\n")
        f.write(f"重叠大小: {Config.CHUNK_OVERLAP}\n")
        f.write(f"嵌入模型: {Config.EMBED_MODEL}\n")
        f.write(f"数据目录: {data_dir}\n")

    return doc_count


def incremental_update(data_dir: str = None, persist_directory: str = None) -> int:
    print("=" * 50)
    print("增量更新向量库")
    print("=" * 50)

    if data_dir is None:
        data_dir = Config.DATA_DIR
    if persist_directory is None:
        persist_directory = Config.VECTOR_DB_PATH

    if not os.path.exists(persist_directory):
        print("向量库不存在，执行完整构建")
        return build_vectorstore(data_dir, persist_directory)

    print("增量更新功能需要更复杂的文档哈希比较逻辑")
    print("建议使用 force_rebuild=True 重新构建")
    return 0


def main():
    import argparse

    parser = argparse.ArgumentParser(description="向量库构建工具")
    parser.add_argument("--data-dir", type=str, help="数据目录路径")
    parser.add_argument("--persist-dir", type=str, help="向量库保存路径")
    parser.add_argument("--force", action="store_true", help="强制重建")
    parser.add_argument("--incremental", action="store_true", help="增量更新")

    args = parser.parse_args()

    try:
        Config.validate()

        if args.incremental:
            count = incremental_update(args.data_dir, args.persist_dir)
        else:
            count = build_vectorstore(
                args.data_dir,
                args.persist_dir,
                force_rebuild=args.force
            )

        if count > 0:
            print(f"\n下一步: 启动API服务")
            print(f"   python api.py")
            print(f"\n测试查询:")
            print(f"   python workflow_langchain.py '你的问题'")

    except Exception as e:
        print(f"错误: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
