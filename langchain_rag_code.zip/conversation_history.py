import time
import logging
from threading import Lock
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)


class ConversationManager:
    """会话历史管理器，支持多会话、自动过期和清理"""

    def __init__(self, max_history: int = 5, ttl_seconds: int = 1800, max_sessions: int = 1000):
        self.sessions: Dict[str, Dict[str, Any]] = {}
        self.lock = Lock()
        self.max_history = max_history
        self.ttl = ttl_seconds
        self.max_sessions = max_sessions

    def get_history(self, session_id: str) -> List[Dict[str, str]]:
        with self.lock:
            session = self.sessions.get(session_id)
            if session:
                session['last_access'] = time.time()
                return list(session['messages'])
            return []

    def add_exchange(self, session_id: str, question: str, answer: str):
        with self.lock:
            if session_id not in self.sessions:
                self._evict_if_needed_locked()
                self.sessions[session_id] = {
                    'messages': [],
                    'created': time.time(),
                    'last_access': time.time()
                }
            session = self.sessions[session_id]
            session['messages'].append({"role": "user", "content": question})
            session['messages'].append({"role": "assistant", "content": answer})
            session['last_access'] = time.time()

            if len(session['messages']) > self.max_history * 2:
                session['messages'] = session['messages'][-(self.max_history * 2):]

    def clear_history(self, session_id: str) -> bool:
        with self.lock:
            if session_id in self.sessions:
                del self.sessions[session_id]
                return True
            return False

    def format_history_for_prompt(self, session_id: str) -> str:
        messages = self.get_history(session_id)
        if not messages:
            return ""

        lines = []
        for msg in messages:
            role = "用户" if msg["role"] == "user" else "助手"
            lines.append(f"{role}: {msg['content']}")
        return "\n".join(lines)

    def _evict_if_needed_locked(self):
        """调用前必须已持有 self.lock"""
        if len(self.sessions) >= self.max_sessions:
            now = time.time()
            expired = [
                sid for sid, s in self.sessions.items()
                if now - s['last_access'] > self.ttl
            ]
            if expired:
                for sid in expired:
                    del self.sessions[sid]
                logger.info(f"清理了 {len(expired)} 个过期会话")
            else:
                oldest = min(self.sessions.items(), key=lambda x: x[1]['last_access'])
                del self.sessions[oldest[0]]
                logger.info(f"会话数已达上限，淘汰最旧会话: {oldest[0]}")

    def cleanup_expired(self):
        with self.lock:
            self._evict_if_needed_locked()

    def get_stats(self) -> Dict[str, Any]:
        with self.lock:
            total_messages = sum(len(s['messages']) for s in self.sessions.values())
            return {
                "active_sessions": len(self.sessions),
                "total_messages": total_messages,
                "max_history_per_session": self.max_history,
                "ttl_seconds": self.ttl,
                "max_sessions": self.max_sessions
            }
